import React from 'react'
 
import Navbar from './components/Navbar'
import Card from './components/Card'
import Hero from './components/Hero'
import data from './data'

import './App.css'

function App() {
  const cards = data.map(item => {
    return (
      <Card
        key={item.id}
        id={item.id}
        title={item.title}
        desc={item.description} // Specify a value for the desc prop
      />
    )
  })

  return (
    <div>
      <Navbar />
      <section className="cards-list">
        {cards}
      </section>
    </div>
  )
}

export default App
