function Navbar() {
    return (
        <nav>
            <img src={require("../images/airbnb-logo.png").default} className="nav--logo" />
        </nav>
    );
}

export default Navbar;
